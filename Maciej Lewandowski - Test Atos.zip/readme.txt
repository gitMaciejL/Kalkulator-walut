1. Program znajduje się na stronie WWW: http://maciejel.xyz/Kalkulator/index.html

2. Program parsuje dane o przelicznikach walut z pliku eurofxref-daily.xml znajdującego się w głównym katalogu i wczytuje nazwy walut do menu rozwijanego.

3. Aby uruchomić program ze swojego komputera należy uruchomić go poprzez serwer (a nie klikając na index.html), w przeciwnym wypadku waluty się nie wczytują, a konsola przeglądarki zwraca błąd CORS. 

4. Można to zrobić na przykład wczytując plik index.html w programie Visual Studio Code i uruchamiając opcję "Open with Live Server" lub w programie Brackets "Podgląd na żywo".